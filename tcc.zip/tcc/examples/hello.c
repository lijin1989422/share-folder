#include <stdio.h>
#include <time.h>
int main(int argc, char **argv)
{
    int i=0;
    for(i=0; i<1000000;++i){
        sleep(10);
        printf("%d\n", i);
    } 
}